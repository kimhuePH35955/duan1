<?php
    include "../model/pdo.php";
    include "../model/danhmuc.php";
    include "../model/sanpham.php";

    include "header.php";
    if(isset($_GET['act'])&&($_GET['act']!="")){
        $act=$_GET['act'];
        switch($act){
            case "listsp":
                if(isset($_POST['clickok'])&& $_POST['clickok']){
                    $keyw=$_POST['keyw'];
                    $iddm = $_POST['iddm'];

                }else{
                    $keyw = '';
                    $iddm = 0;
                }
                $listdanhmuc = loadall_danhmuc();
                $listsanpham = loadall_sanpham($keyw,$iddm);
                include "sanpham/list.php";
                break;
            case "addsp":
                if(isset($_POST['themmoi'])&&$_POST['themmoi']){
                    $iddm = $_POST['iddm'];
                    $tensp = $_POST['tensp'];
                    $giasp = $_POST['giasp'];
                    $mota = $_POST['mota'];
                    $hinh = $_FILES['hinh']['name'];
                    $taget_dir = "../upload/";
                    $taget_file = $taget_dir.basename($_FILES['hinh']['name']);
                    if(move_uploaded_file($_FILES['hinh']['tmp_name'],$taget_file)){
                        echo "Bạn đã up load ảnh thành công";
                    }else{
                        echo "Bạn đã up load ảnh không thành công";
                    }
                    insert_sanpham($tensp,$giasp,$hinh,$mota,$iddm);
                    $thanhcong= "Thêm thành công";


                }
                $listdanhmuc = loadall_danhmuc();
                include "sanpham/add.php";
                break;  
                case "bieudo":
                    include "bieudo.php";
                    break;  
            
        }
    }else{
        include "home.php";
    }
    include "footer.php";
?>
